# DTrader iframe bridge patch — apply to your deriv-dtrader.vercel.app repo

Your live iframe (https://deriv-dtrader.vercel.app/dtrader) is missing two fixes that your
parent app (Freezy Trading Hub) already sends bridge/auth/buy messages for. Without them the
iframe never leaves its default "please log in" state for PKCE (new-account) users, even
though the parent is logged in.

## Files to replace in the DTrader repo (source of the Vercel deployment)

1. `src/App/Components/V2RootGate.jsx`
   - Adds iframe detection (`window.self !== window.top`) so the v2 auth bridge
     (`initBridge()`) always runs when embedded, instead of only when `isV2Api()`
     is already true (which it never is before the bridge handshake completes).

2. `src/_common/base/socket_base.js`
   - Makes `buy()` / `buyAndSubscribe()` detect they're running inside an iframe and,
     instead of sending the trade over DTrader's own WebSocket (which has no valid
     PKCE session), post a `BUY_REQUEST` message to the parent window and await
     `BUY_RESULT`. The parent (already deployed in this Replit project) executes the
     trade on the authenticated PKCE WebSocket and mirrors it into the Run Panel.

## Steps

1. In your DTrader repo, replace the two files above with the ones in this folder.
2. Commit and push — Vercel will auto-deploy.
3. No new dependencies, no other file changes needed.
4. Test: open DTrader from Freezy Trading Hub while logged in with a new account
   (PKCE/OTP). The "Start trading with us / please log in" modal should no longer
   appear, and placing a trade should execute through your account.

The parent-side code that talks to these two files is already live in this Replit
project at `src/components/iframe-wrapper/iframe-wrapper.tsx` (sends `deriv:dtrader:auth`
and handles `BUY_REQUEST`/`BUY_RESULT`) — no changes needed there.
